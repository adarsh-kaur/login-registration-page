

</html><html> 
	<head> 
			<title> coffee co </title>
		
			<link rel="stylesheet" href="fonts/font-awesome.min.css" >
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<link href="download-fonts/stylesheet.css" rel="stylesheet">
			<link rel="stylesheet" href="css/style.css" type="text/css">
            <link rel="stylesheet" href="css/media.css" type="text/css">
			
	</head>
	
	<body> 
	
<div class="outer-div"> 

	<div class="background"> 

		<div class="container"> 
			
			<div class="header">
			
				<div class="logo">
					<a href="#"> <img src="images/Group-1.png"> </a>
				</div>
				
			
					
			</div>
				
					<div class="banner"> 
						<h1>  <span> special coffee for </span> ALTERNATIVE M*LKS </h1>
						
							<div class="banner-image"> 
								<img src="images/Plant Coffee Co_Group Shot.png">
							</div>
						
					</div>
				
		</div>
			
	</div>
		
		
		
		
		<div class="container"> 
			
			<div class="why-plant"> 
				
				<h2> WHY PLANT COFFE CO </h2>
				
					<div class="why-plant-left"> 
						<img src="images/coffee-left.png">
					</div>
					
					<div class="why-plant-right"> 
						<strong>AUSTRALIA'S FIRST COFFE BRAND FOR PLANT BASED M*LKS </strong>
						
							<p>
							We carefully select coffee beans that pair perfectly with alternative milks. 
							When Coffee beans are roasted, they release acids which tend to make your coffee 
							split and curdle and make your coffee look like…..no thanks !
							</p>
							<p> 
							Our coffee blends are crafted for the home barista in mind so they will
							perform and brew your favourite cup of coffee with ease. <br> <br>
							Our coffee beans are freshly roasted in Melbourne.	
							</p>
							
					</div>
				
			</div>
		
		</div>
		
			<div class="background"> 
			
				<div class="container"> 
				
					<div class="medium-roast"> 
					
						<h3> MEDIUM ROAST	</h3>
					
						<p> 
							Flavours of butterscotch, almond and orange zest lead to a subtle stone fruit acidity,
							with a long hazelnut finish.
						</p>
						
							<div class="roast-image"> 
								<img src="images/medium-image.png">
							</div>
								
								<div class="shop-now"> 
									<a href="#"> SHOP NOW </a>
								</div>
								
									
					</div>
					
				</div>
				
			
			</div>
			
			
				<div class="container"> 
					<div class="roast-bottom"> 
										<div class="roast-bottom-inner"> 
										
												<div class="circle-left">
													<img src="images/circle-1.png">
														<h4> THE POWER OF PLANTS </h4>
												</div>
												
												
												<div class="circle-left">
													<img src="images/circle-2.png"> 
														<h4> MADE BY BARISTAS </h4> 
												</div>
												
												
												
												<div class="circle-left">
													<img src="images/circle-3.png">
														<h4> ROASTED IN MELBOURNE </h4>
												</div>
												
												
										</div>
										
									</div>
				</div>
				
				
				
				
			<div class="background"> 
				
				<div class="container">
					
					<div class="dark-roast"> 
						<h3> DARK ROAST </h3>
							<p> Flavours of dark chocolate, walnut and raisin lead to a subtle dark fruit acidity,
								with a long toffee finish</p>
						
							<div class="dark-image"> 
									<img src="images/dark-roast-1.png">
							</div>
							
								<div class="shop-now-dark"> 
									<a href="#"> SHOP NOW </a>
								</div>
						
					</div>	
						
					
				</div>
			
			</div>
			
			
			
		<div class="footer"> 
			
			<div class="container"> 
				
				<div class="border"> 
				 <div class="border-inner">
					<!-- <div class="border-inner-left"> 
						<img src="images/footer-image-1.png">
					</div> -->
					
					
					<!-- <div class="border-inner-right"> 
					
						<div class="footer-heading"> 
							<h3> AUSTRALIA’S FIRST PLANT COFFEE </h3>
						</div>
					
							<div class="name-mail"> 
								<div class="name"> 
									<form> 
										<input type="text" placeholder="Full Name">
										
									</form>
								</div>
								
								<div class="email"> 
									<form> 
										<input type="email" placeholder="Email">
										
									</form>
								</div>
								
							</div>
							
									<div class="submit"> 
										<form>
											<input value=" SUBSCRIBE" type="submit">
										 </form>
									</div>
					
					</div> -->
				</div>	
				</div>
			
			</div>
			
		</div>
				
			
</div>

	
	
	
	</body>

</html>