<?php

session_start();
$_SESSION = array();
session_destroy();

echo "<center>
You have been logged out successfully!
</center>";


// header("location: login.php");

?>
